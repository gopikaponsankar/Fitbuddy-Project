# Project Testing Phase

This folder is prepared for the SmartBridge phase-wise project submission.

Add the phase-specific document/screenshots provided by the team without changing the original project code or file names.
